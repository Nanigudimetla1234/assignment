<?php
if(isset($_POST['submit'])){
    include 'conect.php';
    $flag=0;
    $pernumber=trim($_POST['pernumber']);
     $name= trim($_POST['name']);
     $subjectcode= trim($_POST['subcode']);
     $subjectname = trim($_POST['subnname']);
     $testname=trim($_POST['testname']);
     $date= $_POST['date'];
     $stime=$_POST['stime'];
     $etime = $_POST['etime'];
     $sql4= "SELECT * FROM listassignment";
     $result4=mysqli_query($con,$sql4);
    while ($row =  mysqli_fetch_assoc($result4)) {
        if($testname==$row['testname']){
            $flag=1;
        }
    }
    if($flag==0){
    $sql3 = "INSERT INTO listassignment(pernumber,testname,subjectcode,date,starttime,endtime) VALUES('$pernumber','$testname','$subjectcode',' $date','$stime','$etime')";
    $result = mysqli_query($con, $sql3);
    $sql2 = "CREATE TABLE " .$testname."(id int AUTO_INCREMENT PRIMARY KEY,question varchar(500) NOT NULL,option1 varchar(50) NOT NULL,option2 varchar(50) NOT NULL,option3 varchar(50) NOT NULL,option4 varchar(50) NOT NULL,coption int)";
    $result2 = mysqli_query($con, $sql2);
    $sql3 = "CREATE TABLE marks_".$testname."(id int AUTO_INCREMENT PRIMARY KEY,jntuno varchar(20),marks int)";
    $result3 = mysqli_query($con, $sql3);
    if($result2){
     if ($result) {
        header('location:questions.php?testname='.$testname);
    } else {
        die(mysqli_error($con));
    }}
    else{
        die(mysqli_error($con));
         }
     }
    else{
        echo "table name already used";
    }
        }
else{
    echo "problem";
}






