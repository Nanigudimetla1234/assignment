<?php
require 'conect.php';
$testname = $_GET['testname'];
        if (isset($_POST['submits'])) {

            $question = $_POST['question'];
            $option1 = $_POST['option1'];
            $option2 = $_POST['option2'];
            $option3 = $_POST['option3'];
            $option4 = $_POST['option4'];
            $coption = $_POST['coption'];
            // $sql = " INSERT INTO" . $ttable . "(question,option1,option2,option3,option4,coption) VALUES('$question','$option1','$option2','$option3','$option4','$coption')";
            $sql = "INSERT INTO " . $testname . " VALUES(DEFAULT, '$question','$option1','$option2','$option3','$option4','$coption');";
            $result = mysqli_query($con, $sql);
            if ($result) {
                header('location:questions.php?testname='.$testname);
            } else {
                die(mysqli_error($con));
            }
        }
        if (isset($_POST['preview'])) {
            header('location:preview.php?testname=' . $testname);
        }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="style.css">

    <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">

    <style>
        .flex {
            display: flex;
            flex-direction: column;
        }

        .border {
            border: 2px solid #797979;
            padding: 100px;
        }

        html {
            height: 100%;
        }

        html body {
            margin: 0;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }


        .wrapper {
            position: relative;
            display: inline-block;
            width: 25vw;
        }

        .wrapper2 {
            width: 70vw;
        }

        .wrapper input {
            font-family: "Montserrat", sans-serif;
            background-color: transparent;
            border: none;
            outline: none;
            width: 100%;
            font-size: 1em;
            box-sizing: border-box;
            padding-bottom: 5px;
            border-bottom: 2px solid #797979;
        }

        .wrapper input:focus+.underline {
            width: 100%;
        }

        .wrapper .underline {
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            height: 2px;
            width: 0;
            background-color: #ff8203;
            transition: 0.5s;
        }



        .submit {
            width: 15vw;
        }
    </style>
</head>

<body>
    <div class="border">
        <form action="" method="POST">
            <div class="flex">
                <div class="wrapper wrapper2">
                    <input type="text" placeholder="Question" name="question"><br>
                    <span class="underline"></span>
                </div>
                <div class="wrapper">
                    <input type="text" placeholder="Option1" name="option1"><br>
                    <span class="underline"></span>
                </div>

                <div class="wrapper">
                    <input type="text" placeholder="Option2" name="option2"><br>
                    <span class="underline"></span>
                </div>
                <div class="wrapper">
                    <input type="text" placeholder="Option3" name="option3"><br>
                    <span class="underline"></span>
                </div>
                <div class="wrapper">
                    <input type="text" placeholder="Option4" name="option4"><br>
                    <span class="underline"></span>
                </div>
                <div class="wrapper">
                    <input type="number" placeholder="Enter correct option number" name="coption">
                    <span class="underline"></span>
                </div>
                <div class="submits my-3">
                    <center><input type="submit" class="submit btn btn-primary" name="submits" value="Add Question"></center>

                </div>
            </div>
        </form>
        <form action="" method="POST">
            <center><input type="submit" class="submit btn btn-primary" name="preview" value="preview"></center>
        </form>
    </div>
</body>

</html>
