<?php
    include 'conect.php';
     $jntu = "19341A0655";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php
    $flag2 = 0;
    if (isset($_POST['submit123'])) {
        $testname = $_POST['table'];
        $norows = $_POST['numberofquestions'];
        $flag = 0;
        $count = 0;
        $i = 1;
        $sql5 = "SELECT * FROM marks_" . $testname . " WHERE jntuno='" . $jntu . "';";
        $result5 = mysqli_query($con, $sql5);
        while ($row =  mysqli_fetch_assoc($result5)) {
            if ($jntu == $row['jntuno']) {
                $flag = 1;
            }
        }
        if ($flag == 0) {
            while ($i <= $norows) {
                $ans = $_POST['ans_' . $i];
                $sql = "INSERT INTO `answers` values(DEFAULT,'$jntu','$i','$ans')";
                $res = mysqli_query($con, $sql);
                $sql2 = "select * from " . $testname . " where id='" . $i . "';";
                $result = mysqli_query($con, $sql2);
                while ($row =  mysqli_fetch_assoc($result)) {
                    extract($row);
                    if ($ans == $coption) {
                        $count = $count + 1;
                    }
                }
                $i = $i + 1;
            }
            $sql4 = "INSERT INTO marks_" . $testname . " VALUES(DEFAULT,'" . $jntu . "','" . $count . "')";
            $result4 = mysqli_query($con, $sql4);
            if ($result4) {
                echo "suceess";
            } else {
                echo "error";
            }
            $value = array($count, $norows);
            $values = json_encode($value);
            header('location:results.php?marks=' . $values);
        } else {
    ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Test Already Taken',
                    text: "You can't take the test again"
                });
            </script>
    <?php
            die();
        }
    }
    ?>
</body>

</html>