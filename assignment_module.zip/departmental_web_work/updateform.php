<?php
$con = new mysqli('localhost', 'root', '', 'assignment');
if (!$con) {
    die(mysqli_error($con));
}
$array2 = $_GET['string'];
$array22 = json_decode($array2);
$table = $array22[0];
$qno = $array22[1];
// echo $table;
// echo $qno;
$question = "";
$option1 = "";
$option2 = "";
$option3 = "";
$option4 = "";
?>
<?php
$sql = "SELECT * from " . $table . " where id= '" . $qno . "';";
$result = mysqli_query($con, $sql);
while ($row =  mysqli_fetch_assoc($result)) {
    extract($row);
?>
<?php
        $question1 = $question;
        $option1 = $option1;
        $option2 = $option2;
        $option3 = $option3 ;
        $option4 = $option4 ;
        $coption=$coption;
?>
<?php
}
?>
 <?php
        $arrays=array($question1,$option1,$option2,$option3,$option4,$coption);
        $text = json_encode($arrays);
        echo $text;
        ?> 