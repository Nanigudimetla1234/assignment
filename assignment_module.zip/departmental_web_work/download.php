<?php
include "conect.php";
$table2 = $_GET['table'];
if (isset($_POST['Export'])) {
    $filename = $table2 . 'results.csv';
    $export_data = unserialize($_POST['export_data']);

    // file creation
    $file = fopen($filename, "w");

    foreach ($export_data as $line) {
        fputcsv($file, $line);
    }

    fclose($file);

    // download
    header("Content-Description: File Transfer");
    header("Content-Disposition: attachment; filename=" . $filename);
    header("Content-Type: application/csv; ");

    readfile($filename);

    // deleting file
    unlink($filename);
    exit();
}
?>
<!doctype html>
<html>

<head>
    <title>Downloading_Results</title>
    <link href="style.css" rel="stylesheet" type="text/css">
    <style>
        .btn {
            padding: 10px;
            margin: 15px;
        }

        .btn {
            box-sizing: border-box;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-color: transparent;
            border: 2px solid #e74c3c;
            border-radius: 0.6em;
            color: #e74c3c;
            cursor: pointer;
            display: flex;
            align-self: center;
            font-size: 1rem;
            font-weight: 400;
            line-height: 1;
            margin: 20px;
            padding: 1.2em 2.8em;
            text-decoration: none;
            text-align: center;
            text-transform: uppercase;
            font-family: "Montserrat", sans-serif;
            font-weight: 700;
        }

        .btn:hover,
        .btn:focus {
            color: black;
            outline: 0;
        }


        .third {
            border-color: #3498db;
            color: #fff;
            box-shadow: 0 0 40px 40px #3498db inset, 0 0 0 0 #3498db;
            transition: all 150ms ease-in-out;
        }

        .third:hover {
            box-shadow: 0 0 10px 0 #3498db inset, 0 0 10px 4px #3498db;
        }
    </style>

</head>

<body>
    <div class="container">

        <form method='post' action=''>
            <input type='submit' value='Download Results sheet' name='Export' class="btn third">

            <table border='1' style='border-collapse:collapse;'>
                <tr>
                    <th>ID</th>
                    <th>jntuno</th>
                    <th>marks</th>
                </tr>
                <?php
                $query = "SELECT * FROM " . $table2 . " ORDER BY id asc";
                $result = mysqli_query($con, $query);
                $user_arr = array();
                while ($row = mysqli_fetch_array($result)) {
                    $id = $row['id'];
                    $jntu = $row['jntuno'];
                    $marks = $row['marks'];
                    $user_arr[] = array($id, $jntu, $marks);
                ?>
                    <tr>
                        <td><?php echo $id; ?></td>
                        <td><?php echo $jntu; ?></td>
                        <td><?php echo $marks; ?></td>
                    </tr>
                <?php
                }
                ?>
            </table>
            <?php
            $serialize_user_arr = serialize($user_arr);
            ?>
            <textarea name='export_data' style='display: none;'><?php echo $serialize_user_arr; ?></textarea>
        </form>
    </div>
</body>

</html>