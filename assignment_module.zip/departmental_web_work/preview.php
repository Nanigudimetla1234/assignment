<?php
include 'conect.php';
$testname = $_GET['testname'];
if (isset($_POST['submit123'])) {
    header('location:questions.php?testname=' . $testname);
}


if (isset($_POST['submits'])) {
    header('location:submit.php');
}
if (isset($_POST['update'])) {
    header('location:update.php?testname=' . $testname);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- JavaScript Bundle with Popper -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <title></title>
    <style>
        /* .forms {
            display: flex;
            flex-direction: column;
        } */

        .forms1 {
            margin-left: 45vw;
        }

        body {
            padding-top: 30px;
        }

        .test>.title {
            text-decoration: underline;
        }

        .test>.module:before {
            content: "Module:";
            font-weight: bold;
            margin-right: 8px;
        }

        .test>.level:before {
            content: "Level:";
            font-weight: bold;
            margin-right: 8px;
        }

        .test .question .choices {
            min-width: 300px;
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .test .question .choices .choice {
            position: relative;
        }

        .test .question .choices .choice input {
            position: absolute;
            clip: rect(0, 0, 0, 0);
        }

        .test .question .choices .choice label {
            font-weight: normal;
            cursor: pointer;
            display: block;
            padding: 9px;
            border-radius: 5px;
            background: #ddd;
        }

        h5 {
            text-transform: uppercase;
            margin: 0 auto;
            background-image: linear-gradient(90deg, #ff7d7d, #ce5ce8);
            background-clip: text;
            -moz-background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
        }
    </style>
</head>

<body>
    <div class="container">

        <form>
            <?php

            $sql = "SELECT * FROM `$testname`";
            $result = mysqli_query($con, $sql);
            while ($row =  mysqli_fetch_assoc($result)) {
                extract($row);
            ?>
                <!-- 
            </div> -->

                <div class="test col-md-6 col-md-offset-3">
                    <h5>QUESTION NUMBER:<?php echo $id; ?></h5><br>
                    <div class="question">
                        <h3 class="title"><?php echo $question ?></h3>
                        <div class="choices">
                            <div class="choice">
                                <input type="radio" value="<?php echo $option1; ?>" name="ans" id="Apple" />
                                <label for="Apple"><i class="fa-solid fa-check fa-2xs"></i></span><?php echo $option1; ?>
                                </label>
                            </div>
                            <div class="choice">
                                <input type="radio" value="<?php echo $option2; ?>" name="ans" id="Banana" />
                                <label for="Banana"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><?php echo $option2; ?>
                                </label>
                            </div>
                            <div class="choice">
                                <input type="radio" value="<?php echo $option3; ?>" name="ans" id="Spider" />
                                <label for="Spider"><span class="glyphicon glyphicon-ok"></span><?php echo $option3 ?>
                                </label>
                            </div>
                            <div class="choice">
                                <input type="radio" value="<?php echo $option4; ?>" name="ans" id="Strawberry" />
                                <label for="Strawberry"><span class="glyphicon glyphicon-ok"></span><?php echo $option4 ?>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
        </form>
    <?php
            }
    ?>
    <center>
        <div class="container">
            <div class="forms my-4 row mx-5 ">
                <div class="col-sm">
                    <form action="" method="POST">
                        <input type="submit" name="submit123" class="btn btn-outline-primary btn-lg " value="BACK">
                    </form>
                </div>
                <div class="col-sm left">
                    <form action="" method="POST">
                        <input type="submit" name="update" class="btn btn-outline-secondary btn-lg" value="update">
                    </form>
                </div>
                <div class="col-sm left">
                    <form action="" method="POST">
                        <input type="submit" name="submits" class="btn  btn-outline-success btn-lg" value="submit">
                    </form>
                </div>


            </div>
        </div>

    </center>
</body>
</div>

</html>