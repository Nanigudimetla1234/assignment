<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>ASSIGNMENT</title>
    <!-- mannual css -->
    <link rel="stylesheet" href="style.css">

    <!-- addon css -->
    <style>

        .ball {
            position: absolute;
            border-radius: 100%;
            opacity: 0.7;
        }
        body{
            background-color:rgb(25,25,25);
            width: 100vw;
            overflow: hidden;
        }
    </style>
</head>

<body>
    <div class="container con">
        <div class="flex">
            <div class="center">
                <button class="btn butt btn-outline-primary"><a href="assignment.php" style="color:white;text-decoration:none;">CREATE ASSIGNMENT</a></button>
            </div>
            <div></div>
            <div class="center">
                <button class="btn butt btn-outline-primary"><a href="tresults.php" style="color:white;text-decoration:none;">VIEW RESULTS</a></button>
            </div>
        </div>
    </div>
</body>
<script>
    // Some random colors
    const colors = ["#3CC157", "#2AA7FF", "#1B1B1B", "#FCBC0F", "#F85F36"];

    const numBalls = 50;
    const balls = [];

    for (let i = 0; i < numBalls; i++) {
        let ball = document.createElement("div");
        ball.classList.add("ball");
        ball.style.background = colors[Math.floor(Math.random() * colors.length)];
        ball.style.left = `${Math.floor(Math.random() * 100)}vw`;
        ball.style.top = `${Math.floor(Math.random() * 100)}vh`;
        ball.style.transform = `scale(${Math.random()})`;
        ball.style.width = `${Math.random()}em`;
        ball.style.height = ball.style.width;

        balls.push(ball);
        document.body.append(ball);
    }

    // Keyframes
    balls.forEach((el, i, ra) => {
        let to = {
            x: Math.random() * (i % 2 === 0 ? -11 : 11),
            y: Math.random() * 12
        };

        let anim = el.animate(
            [{
                    transform: "translate(0, 0)"
                },
                {
                    transform: `translate(${to.x}rem, ${to.y}rem)`
                }
            ], {
                duration: (Math.random() + 1) * 2000, // random duration
                direction: "alternate",
                fill: "both",
                iterations: Infinity,
                easing: "ease-in-out"
            }
        );
    });
</script>

</html>