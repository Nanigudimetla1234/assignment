<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-color: darken(#252B37,4%);
        }
    </style>

</head>

<body>
    <div class="card forms">
        <div class="card-body">
            <h5 class="card-title">Create New Assignment</h5><br>


            <form class="row g-3" action="assigntable1.php" method="POST">
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingper" name="pernumber" placeholder=" ENTER YOUR PER NUMBER">
                        <label for="floatingper">PER NUMBER</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingname" placeholder="Password" name="name">
                        <label for="floatingname">NAME</label>
                    </div>
                </div>


                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingcode" name="subcode" placeholder="ENTER SUBJECT CODE">
                        <label for="floatingcode">SUBJECT CODE</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingsubname" name="subnname" placeholder="SUBJECT NAME">
                        <label for="floatingsubname">SUBJECT NAME</label>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingtestname" name="testname" placeholder="ENTER THE TEST NAME">
                        <label for="floatingtestname">TEST NAME</label>
                    </div>
                </div>


                <div class="col-md-4">
                    <div class="form-floating">
                        <input type="date" class="form-control" id="floatingdate" name="date" placeholder="DATE OF EXAM">
                        <label for="floatingdate">DATE</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-floating">
                        <input type="time" class="form-control" id="floatingsstart" name="stime" placeholder=" TEST START TIME">
                        <label for="floatingstart">START TIME </label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-floating">
                        <input type="time" class="form-control" id="floatingend" name="etime" placeholder="TEST END TIME">
                        <label for="floatingend">END TIME</label>
                    </div>
                </div>


                <div class="text-center">
                    <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                    <button type="reset" class="btn btn-primary">Reset</button>
                </div>

            </form><!-- End floating Labels Form -->

        </div>
    </div>
</body>

</html>