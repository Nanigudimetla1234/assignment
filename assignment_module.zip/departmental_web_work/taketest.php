<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>take test</title>
    <style>
        * {
            margin: 0;
            box-sizing: border-box;
        }

        body {
            display: flex;
            align-items: center;
            background-color: #031525;
            padding: 30px 0;
        }

        .container {
            display: grid;
            place-items: center;
            width: 230px;
            aspect-ratio: 0.7;
            margin: auto;
            /* background: linear-gradient(50deg, darkgreen, Teal); */
            border: linear-gradient(50deg, darkgreen, Teal);
            position: relative;
            border-radius: 5%;
            padding: 3px;
        }

        .container::before {
            content: '';
            width: 430px;
            height: 25px;
            position: absolute;
            transform: rotate(-52deg) translate(0, -180px);
        }

        .card {
            display: grid;
            place-items: center;
            width: 100%;
            aspect-ratio: 0.7;
            border-radius: 5%;
            background-color: #111522;
            color: #858585;
            border-image: linear-gradient(to right, #52c234, #006400) 1;
            /* position: relative; */
        }

        .container:hover::before {
            animation: effetto 3s infinite;
        }

        .container:hover .card {
            color: #fff;
        }

        p {
            color: bisque;
            font-size: 1.1rem;
        }

        @keyframes effetto {
            50% {
                transform: rotate(-52deg) translate(0, 180px)
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row">
            <?php
            include 'conect.php';
            date_default_timezone_set("Asia/calcutta");
            $i = 0;
            $current_time = date("H:i:s");
            $date = date("Y-m-d");
            $fetch_test = "SELECT * FROM listassignment WHERE starttime < '" . $current_time . "' and endtime >'" . $current_time . "' ;";
            $result = mysqli_query($con, $fetch_test);
            while ($row =  mysqli_fetch_assoc($result)) {
                extract($row);
            ?>
                <div class="card col-6 my-4">
                    <div class="txt">
                        <span>TEST NAME</span>:<p><?php echo $testname ?></p>
                        <span>subject code</span>:<p><?php echo $subjectcode ?></p>
                        <form action="display.php" method="POST">
                            <input type="hidden" value="<?php echo $testname ?>" name="tname">
                            <input type="submit" class="btn btn-outline-success" value="take assignment">
                        </form>
                    </div>
                </div>

            <?php
                $i++;
            }
            ?>
        </div>
    </div>
</body>

</html>