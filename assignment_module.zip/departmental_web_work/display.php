<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- JavaScript Bundle with Popper -->
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <!-- google fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Mukta:wght@200&family=Roboto+Serif:ital,wght@0,200;1,300&family=Roboto:wght@300&display=swap" rel="stylesheet">

    <!-- sweet alert -->
    <link href="//cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
    <title>Questions</title>

    <style>
        body {
            font-family: 'Mukta', sans-serif;
        }

        label {
            font-size: 130%;
        }

        .test {
            border: 0.5px solid grey;
            width: 100%;
            padding-left: 3vw;
        }
    </style>
</head>

<body>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php
    include 'conect.php';
    $testname = $_POST['tname'];
    ?>
    <?php
    $flag2 = 0;
    if (isset($_POST['submit123'])) {
        $jntu="19341A0555";
        $norows = $_POST['numberofquestions'];
        $flag = 0;
        $count = 0;
        $i = 1;
        $sql5 = "SELECT * FROM marks_" . $testname . " WHERE jntuno='" . $jntu . "';";
        $result5 = mysqli_query($con, $sql5);
        while ($row =  mysqli_fetch_assoc($result5)) {
            echo "test ";
            if ($jntu == $row['jntuno']) {
                $flag = 1;
            }
        }
        if ($flag == 0) {
            while ($i <= $norows) {
                $ans = $_POST['ans_' . $i];
                $sql = "INSERT INTO `answers` values(DEFAULT,'$jntu','$i','$ans')";
                $res = mysqli_query($con, $sql);
                $sql2 = "select * from " . $testname . " where id='" . $i . "';";
                $result = mysqli_query($con, $sql2);
                while ($row =  mysqli_fetch_assoc($result)) {
                    extract($row);
                    if ($ans == $coption) {
                        $count = $count + 1;
                    }
                }
                $i = $i + 1;
            }
            $sql4 = "INSERT INTO marks_".$testname." VALUES(DEFAULT,'".$jntu. "','" . $count . "')";
            $result4 = mysqli_query($con, $sql4);
            if ($result4) {
                echo "suceess";
            } else {
                echo "error";
            }
            $value = array($count, $norows);
            $values = json_encode($value);
            header('location:results.php?marks=' . $values);
        } else {
    ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Test Already Taken',
                    text: "You can't take the test again"
                });
            </script>
    <?php
            die();
        }
    }
    ?>
    <div class="container-fluid">
        <div class="name">
            <h1>Assignment Name: <?php echo $testname; ?></h1>
        </div>
        <form action="marks.php" method="POST">
            <input type="hidden" name="table" value="<?php echo $testname; ?>">
            <?php
            $sql = "SELECT * FROM `$testname`;";
            $result = mysqli_query($con, $sql);
            while ($row =  mysqli_fetch_assoc($result)) {
                extract($row);
            ?>
                <div class="test col-md-6 col-md-offset-3 my-4">
                    <div class="question my-3">
                        <h5 style="color: orange;">Question Number:<?php echo $id; ?></h5>
                        <h2 class="title">Q:<?php echo $question ?></h2>
                        <input class="form-check-input" type="radio" id="Ans1_<?php echo $id; ?>" name="ans_<?php echo $id; ?>" value="1">
                        <label for="Ans1_<?php echo $id; ?>" class="form-check-label"><?php echo $option1; ?></label><br>
                        <input class="form-check-input" type="radio" id="Ans2_<?php echo $id; ?>" name="ans_<?php echo $id; ?>" value="2">
                        <label for="Ans2_<?php echo $id; ?>" class="form-check-label"><?php echo $option2; ?></label><br>
                        <input class="form-check-input" type="radio" id="Ans3_<?php echo $id; ?>" name="ans_<?php echo $id; ?>" value="3">
                        <label for="Ans3_<?php echo $id; ?>" class="form-check-label"><?php echo $option3; ?></label><br>
                        <input class="form-check-input" type="radio" id="Ans4_<?php echo $id; ?>" name="ans_<?php echo $id; ?>" value="4">
                        <label for="Ans4_<?php echo $id; ?>" class="form-check-label"> <?php echo $option4; ?></label><br>
                    </div>
                </div>
            <?php
            }
            ?>
            <input type="hidden" name="numberofquestions" value="<?php echo $id; ?>">
            <div class="submit my-4 " style="display: flex;justify-content:center">
                <div class="div">
                    <input type="submit" name="submit123" class="btn btn-primary " onclick="alerts();" value="submit answers">
                </div>
            </div>
        </form>
    </div>
    </div>

</body>

</html>