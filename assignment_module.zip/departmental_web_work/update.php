<?php include 'conect.php';
$testname = $_GET['testname'];
if (isset($_POST['submits'])) 
   {
    $qno=$_POST['qnumber'];
    $question = $_POST['question'];
    $option1 = $_POST['option1'];
    $option2 = $_POST['option2'];
    $option3 = $_POST['option3'];
    $option4 = $_POST['option4'];
    $coption = $_POST['coption'];
    $sql = "UPDATE ".$testname." SET question='".$question."',option1='".$option1."',option2='".$option2."',option3='".$option3."',option4='".$option4."',coption='".$coption."' WHERE id='".$qno."';";
    $result = mysqli_query($con,$sql);
    if ($result) {
        header('location:questions.php?testname='.$testname);
    } else {
        die(mysqli_error($con));
    }
   }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="style.css">

    <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">

    <style>
        .flex {
            display: flex;
            flex-direction: column;
        }

        .border {
            border: 2px solid #797979;
            padding: 100px;
        }

        html {
            height: 100%;
        }

        html body {
            margin: 0;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }


        .wrapper {
            position: relative;
            display: inline-block;
            width: 25vw;
        }

        .wrapper2 {
            width: 70vw;
        }

        .wrapper input {
            font-family: "Montserrat", sans-serif;
            background-color: transparent;
            border: none;
            outline: none;
            width: 100%;
            font-size: 1em;
            box-sizing: border-box;
            padding-bottom: 5px;
            border-bottom: 2px solid #797979;
        }

        .wrapper input:focus+.underline {
            width: 100%;
        }

        .wrapper .underline {
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            height: 2px;
            width: 0;
            background-color: #ff8203;
            transition: 0.5s;
        }



        .submit {
            width: 15vw;
        }
    </style>
</head>

<body>
    <div class="border">
        <form action="" method="POST">
            <div class="flex">
                <div class="wrapper">
                    <input type="text" placeholder="ENTER THE QUESTION NUMBER" name="qnumber" onkeyup="GetDetail(this.value)"><br>
                    <span class="underline"></span>
                </div>
                <div class="wrapper wrapper2">
                    <input type="text" placeholder="Question" name="question" id="question"> <br>
                    <span class="underline"></span>
                </div>
                <div class="wrapper">
                    <input type="text" placeholder="Option1" name="option1" id="option1"><br>
                    <span class="underline"></span>
                </div>

                <div class="wrapper">
                    <input type="text" placeholder="Option2" name="option2" id="option2"><br>
                    <span class="underline"></span>
                </div>
                <div class="wrapper">
                    <input type="text" placeholder="Option3" name="option3" id="option3"><br>
                    <span class="underline"></span>
                </div>
                <div class="wrapper">
                    <input type="text" placeholder="Option4" name="option4" id="option4"><br>
                    <span class="underline"></span>
                </div>
                <div class="wrapper">
                    <input type="number" placeholder="Enter correct option number" name="coption" id="coption">
                    <span class="underline"></span>
                </div>
                <div class="submits my-3">
                    <center><input type="submit" class="submit btn btn-primary" name="submits" value="UPDATE"></center>

                </div>
            </div>
        </form>
    </div>
</body>
<script>
    const tablename = '<?php echo $testname ?>';

    function GetDetail(str) {
        console.log(tablename);
        const strings = str;
        console.log(strings);
        const array = new Array(tablename, strings);
        console.log(array);
        const array2 = JSON.stringify(array);
        if (str.length == 0) {
            document.getElementById("question").value = "";
            document.getElementById("option1").value = "";
            document.getElementById("option2").value = "";
            document.getElementById("option3").value = "";
            document.getElementById("option4").value = "";
            document.getElementById("coption").value = "";
            return;
        } else {
            console.log("fetching happens");

            fetch("updateform.php?string=" + array2, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => {console.log(response);
                return response.json()})
                .then(obj => {
                    console.log(obj);
                    const question = obj[0];
                    const option1 = obj[1];
                    const option2 = obj[2];
                    const option3 = obj[3];
                    const option4 = obj[4];
                    const answer = obj[5];
                    document.getElementById("question").value = question;
                    document.getElementById("option1").value = option1;
                    document.getElementById("option2").value = option2;
                    document.getElementById("option3").value = option3;
                    document.getElementById("option4").value = option4;
                    document.getElementById("coption").value = answer;
                })
                .catch(err => console.log(err))
        }
    };
</script>


</html>