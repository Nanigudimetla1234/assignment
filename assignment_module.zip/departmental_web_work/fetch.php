<?php
$name=$_GET['getname'];



?>